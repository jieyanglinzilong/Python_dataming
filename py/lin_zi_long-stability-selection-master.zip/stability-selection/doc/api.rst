API Documentation
=================

* :doc:`stability_selection`
* :doc:`randomized_lasso`